document.addEventListener('DOMContentLoaded', () => {

    // Header shadow on scroll
    const navbar = document.querySelector('.navbar');
    window.addEventListener('scroll', () => {
        if (window.scrollY > 50) {
            navbar.style.boxShadow = "0 5px 20px rgba(0,0,0,0.1)";
        } else {
            navbar.style.boxShadow = "none";
        }
    });

    // Smooth scroll for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth'
                });
            }
        });
    });

    // Simple text glitch effect trigger
    const glitchElement = document.querySelector('.glitch-text');
    setInterval(() => {
        if (glitchElement) {
            glitchElement.classList.add('active');
            setTimeout(() => {
                glitchElement.classList.remove('active');
            }, 200);
        }
    }, 5000);

    // --- Quotes Carousel System ---
    const quotes = [
        {
            text: "Security is not a product, it’s a process.",
            author: "Kevin Mitnick - World-Famous Hacker"
        },
        {
            text: "Amateurs hack systems, professionals hack people.",
            author: "Bruce Schneier - Cryptographer"
        },
        {
            text: "The only truly secure system is one that is powered off.",
            author: "Gene Spafford - Computer Scientist"
        },
        {
            text: "There are two types of companies: those that have been hacked, and those who don't know it yet.",
            author: "John Chambers - Former Cisco CEO"
        },
        {
            text: "It takes 20 years to build a reputation and few minutes of cyber-incident to ruin it.",
            author: "Stéphane Nappo - CISO"
        },
        {
            text: "The best antivirus is the human brain.",
            author: "Security Principle"
        },
        {
            text: "Remote work is advanced, and so must be its security.",
            author: "Shainal Badusha - Consultant"
        }
    ];

    let currentQuoteIndex = 0;
    const quoteTextElem = document.getElementById('quote-display');
    const quoteAuthorElem = document.getElementById('quote-author');

    function animateQuote(quoteObj) {
        // Fade out
        quoteTextElem.style.opacity = 0;
        quoteAuthorElem.style.opacity = 0;
        quoteTextElem.style.transition = 'opacity 0.5s ease';
        quoteAuthorElem.style.transition = 'opacity 0.5s ease';

        setTimeout(() => {
            // Typewriter effect logic could go here, but a clean fade is often more professional for long text
            quoteTextElem.textContent = `"${quoteObj.text}"`;
            quoteAuthorElem.textContent = `- ${quoteObj.author}`;

            // Fade in
            quoteTextElem.style.opacity = 1;
            quoteAuthorElem.style.opacity = 1;
        }, 500);
    }

    // Initialize first quote
    animateQuote(quotes[0]);

    // Rotate quotes
    setInterval(() => {
        currentQuoteIndex = (currentQuoteIndex + 1) % quotes.length;
        animateQuote(quotes[currentQuoteIndex]);
    }, 6000); // Change every 6 seconds

});
